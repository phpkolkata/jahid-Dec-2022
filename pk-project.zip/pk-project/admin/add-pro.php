<?php
require("lib/session_security.php");

require 'db.php';
$sql = "select * from category";
$res = mysqli_query($con, $sql);
?>
<form action="adding-pro.php" method="post" enctype="multipart/form-data">
Select Category:
<select name="cat_id">
<?php
while($row = mysqli_fetch_assoc($res)){
	echo "<option value='$row[id]'>$row[name]</option>";
}
?>
</select>
<br>
Name: <input type="text" name="nm" ><br>
Price: <input type="text" name="prc" ><br>
Description: <textarea cols="15" rows="8" name="dsc"></textarea> <br>
Image : <input type="file" name="im"><br>
isActive: 
<input type="radio" name="isActive" value="y" checked="checked"> Yes 
<input type="radio" name="isActive" value="n"> No
<br>
<input type="submit" value="Add"> 
</form>