<?php
require("lib/session_security.php");

require("db.php");
$id = $_REQUEST['id'];

$sql = "delete from `product` where `id`='$id'";
$res = mysqli_query($con, $sql);

header("location:product.php?msg=record deleted");